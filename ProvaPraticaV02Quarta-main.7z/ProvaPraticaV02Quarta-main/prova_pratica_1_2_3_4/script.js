var textArea = document.getElementById("text-input");
var charCount = document.getElementById("char-count");
var wordCount = document.getElementById("word-count");
var name = document.getElementById("your-name");

name.innerText = "Seu Nome Aqui";

function contarTexto() {
    var texto = textArea.value;
    charCount.innerText = texto.length;

    var palavras = texto.trim().split(/\s+/);
    if (texto.trim() === "") {
        wordCount.innerText = 0;
    } else {
        wordCount.innerText = palavras.length;
    }
}

textArea.addEventListener("input", contarTexto);
contarTexto();
