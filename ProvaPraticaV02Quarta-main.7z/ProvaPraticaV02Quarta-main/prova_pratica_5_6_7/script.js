document.addEventListener('DOMContentLoaded', () => {
    // Obter referências para os elementos HTML
    const pesoInput = document.getElementById('peso');
    const alturaInput = document.getElementById('altura');
    const calcularBtn = document.getElementById('calcular-btn');
    const resultadoDiv = document.getElementById('resultado');
    const erroMensagemDiv = document.getElementById('erro-messagem');
    const nomeSpan = document.getElementById('your-name');

    // Função para adicionar seu nome no rodapé
    function addYourName() {
        nomeSpan.textContent = "Igor Augusto"; // Substitua pelo seu nome real
    }

    function removeClassResultadoDiv() {
        const cls = ["resultado-baixo", "resultado-normal", "resultado-sobre", "resultado-obesidade"];
        resultadoDiv.classList.remove(...cls);
    }

    calcularBtn.addEventListener('click', () => {
        removeClassResultadoDiv();
        erroMensagemDiv.textContent = "";
        resultadoDiv.textContent = "";

        const peso = parseFloat(pesoInput.value);
        const altura = parseFloat(alturaInput.value);

        if (isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0) {
            erroMensagemDiv.textContent = "Por favor, insira valores válidos para peso e altura.";
            return;
        }

        const imc = peso / (altura * altura);
        const imcFormatado = imc.toFixed(2);

        let classificacao = "";
        let classeCSS = "";

        if (imc < 18.5) {
            classificacao = "Abaixo do peso";
            classeCSS = "resultado-baixo";
        } else if (imc < 25) {
            classificacao = "Peso normal";
            classeCSS = "resultado-normal";
        } else if (imc < 30) {
            classificacao = "Sobrepeso";
            classeCSS = "resultado-sobre";
        } else if (imc < 35) {
            classificacao = "Obesidade Grau I";
            classeCSS = "resultado-obesidade";
        } else if (imc < 40) {
            classificacao = "Obesidade Grau II";
            classeCSS = "resultado-obesidade";
        } else {
            classificacao = "Obesidade Grau III (Mórbida)";
            classeCSS = "resultado-obesidade";
        }

        resultadoDiv.textContent = `IMC: ${imcFormatado} - ${classificacao}`;
        resultadoDiv.classList.add(classeCSS);
    });

    addYourName();
});
