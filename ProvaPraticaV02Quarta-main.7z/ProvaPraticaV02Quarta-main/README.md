# ProvaPraticaV02- Quarta-Feira 

### Resolvida
